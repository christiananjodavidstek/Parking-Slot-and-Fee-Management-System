import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ParkingLot parkingLot = new ParkingLot();
        int choice = 0;

        do {
            System.out.println("\n=============================================");
            System.out.println("    PARKING SLOT & FEE MANAGEMENT SYSTEM");
            System.out.println("=============================================");
            parkingLot.displaySummaryHeader();
            System.out.println("---------------------------------------------");
            System.out.println("1. View Visual Parking Map");
            System.out.println("2. Park a Vehicle (Issue Ticket)");
            System.out.println("3. Search Vehicle by Plate Number");
            System.out.println("4. Release Slot / Checkout (Issue Receipt)");
            System.out.println("5. View Revenue & Shift Summary");
            System.out.println("6. Save & Exit");
            System.out.print("Select an option (1-6): ");

            choice = readIntSafe(scanner);

            switch (choice) {
                case 1:
                    parkingLot.displayVisualGrid();
                    break;

                case 2:
                    System.out.println("\nSelect Vehicle Type:");
                    System.out.println("1. MOTORCYCLE (Php 15.00 Flat Rate)");
                    System.out.println("2. CAR        (Php 25.00 Flat Rate)");
                    System.out.print("Enter choice (1-2): ");
                    int typeChoice = readIntSafe(scanner);

                    VehicleType type;
                    if (typeChoice == 1) type = VehicleType.MOTORCYCLE;
                    else if (typeChoice == 2) type = VehicleType.CAR;
                    else {
                        System.out.println("Invalid vehicle selection.");
                        break;
                    }

                    System.out.print("Enter Vehicle Plate Number (e.g., ABC-1234): ");
                    String plate = scanner.nextLine();

                    System.out.print("How many hours will the user park? ");
                    int hours = readIntSafe(scanner);

                    parkingLot.parkVehicle(type, plate, hours);
                    break;

                case 3:
                    System.out.print("Enter Plate Number to search: ");
                    String searchPlate = scanner.nextLine();
                    parkingLot.searchByPlate(searchPlate);
                    break;

                case 4:
                    System.out.println("\nCheckout by:");
                    System.out.println("1. Slot Number");
                    System.out.println("2. Plate Number");
                    System.out.print("Enter choice (1-2): ");
                    int outChoice = readIntSafe(scanner);

                    if (outChoice == 1) {
                        System.out.print("Enter Slot Number (e.g., 101 or 201): ");
                        int slotNum = readIntSafe(scanner);
                        parkingLot.releaseBySlot(slotNum);
                    } else if (outChoice == 2) {
                        System.out.print("Enter Plate Number: ");
                        String outPlate = scanner.nextLine();
                        parkingLot.releaseByPlate(outPlate);
                    } else {
                        System.out.println("Invalid selection.");
                    }
                    break;

                case 5:
                    parkingLot.displayRevenueReport();
                    break;

                case 6:
                    parkingLot.saveAll();
                    System.out.println("All records saved to JSON. Exiting system...");
                    break;

                default:
                    System.out.println("Invalid option. Please enter a number from 1 to 6.");
            }
        } while (choice != 6);

        scanner.close();
    }

    // Safely reads an integer without crashing if the user enters text
    private static int readIntSafe(Scanner scanner) {
        try {
            String input = scanner.nextLine().trim();
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}