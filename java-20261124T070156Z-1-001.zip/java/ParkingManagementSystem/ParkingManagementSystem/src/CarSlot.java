public class CarSlot extends ParkingSlot {
    private static final double FLAT_RATE = 25.00;

    public CarSlot(int slotNumber) {
        super(slotNumber, VehicleType.CAR);
    }

    public CarSlot(int slotNumber, SlotStatus status, String plateNumber,
                   int hoursParked, String entryTime, String transactionId) {
        super(slotNumber, VehicleType.CAR, status, plateNumber, hoursParked, entryTime, transactionId);
    }

    @Override
    public double calculateFee() {
        return FLAT_RATE;
    }
}