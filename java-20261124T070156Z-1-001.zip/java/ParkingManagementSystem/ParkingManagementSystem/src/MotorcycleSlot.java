public class MotorcycleSlot extends ParkingSlot {
    private static final double FLAT_RATE = 15.00;

    public MotorcycleSlot(int slotNumber) {
        super(slotNumber, VehicleType.MOTORCYCLE);
    }

    public MotorcycleSlot(int slotNumber, SlotStatus status, String plateNumber,
                          int hoursParked, String entryTime, String transactionId) {
        super(slotNumber, VehicleType.MOTORCYCLE, status, plateNumber, hoursParked, entryTime, transactionId);
    }

    @Override
    public double calculateFee() {
        return FLAT_RATE;
    }
}