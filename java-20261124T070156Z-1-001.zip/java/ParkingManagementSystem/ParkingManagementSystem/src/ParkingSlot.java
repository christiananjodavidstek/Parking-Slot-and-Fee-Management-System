import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public abstract class ParkingSlot {
    private int slotNumber;
    private VehicleType allowedVehicleType;
    private SlotStatus status;
    private String plateNumber;
    private int hoursParked;
    private String entryTime;
    private String transactionId;

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a");

    // Constructor for new empty slots
    public ParkingSlot(int slotNumber, VehicleType allowedVehicleType) {
        this(slotNumber, allowedVehicleType, SlotStatus.AVAILABLE, "NONE", 0, "N/A", "N/A");
    }

    // Full constructor for restoring state from JSON
    public ParkingSlot(int slotNumber, VehicleType allowedVehicleType, SlotStatus status,
                       String plateNumber, int hoursParked, String entryTime, String transactionId) {
        this.slotNumber = slotNumber;
        this.allowedVehicleType = allowedVehicleType;
        this.status = status;
        this.plateNumber = plateNumber;
        this.hoursParked = hoursParked;
        this.entryTime = entryTime;
        this.transactionId = transactionId;
    }

    // Abstract method: Subclasses define their own flat rate (Polymorphism)
    public abstract double calculateFee();

    // Getters
    public int getSlotNumber() { return slotNumber; }
    public VehicleType getAllowedVehicleType() { return allowedVehicleType; }
    public SlotStatus getStatus() { return status; }
    public String getPlateNumber() { return plateNumber; }
    public int getHoursParked() { return hoursParked; }
    public String getEntryTime() { return entryTime; }
    public String getTransactionId() { return transactionId; }

    // Park a vehicle and print an entry ticket
    public void parkVehicle(String plateNumber, int hours, String txnId) {
        if (status != SlotStatus.AVAILABLE) {
            System.out.println("Slot #" + slotNumber + " is already occupied.");
            return;
        }
        this.status = SlotStatus.OCCUPIED;
        this.plateNumber = plateNumber.toUpperCase().trim();
        this.hoursParked = hours;
        this.entryTime = LocalDateTime.now().format(FORMATTER);
        this.transactionId = txnId;

        printTicket("ENTRY PARKING TICKET", this.entryTime, calculateFee());
    }

    // Release slot, print official receipt, and return collected fee
    public double releaseSlot() {
        if (status != SlotStatus.OCCUPIED) {
            System.out.println("Slot #" + slotNumber + " is currently empty.");
            return 0.0;
        }
        double feeCollected = calculateFee();
        String exitTime = LocalDateTime.now().format(FORMATTER);

        printTicket("OFFICIAL EXIT RECEIPT", exitTime, feeCollected);

        // Reset slot state
        this.status = SlotStatus.AVAILABLE;
        this.plateNumber = "NONE";
        this.hoursParked = 0;
        this.entryTime = "N/A";
        this.transactionId = "N/A";

        return feeCollected;
    }

    private void printTicket(String title, String timestamp, double amount) {
        System.out.println("\n+------------------------------------------+");
        System.out.printf("| %-40s |\n", title);
        System.out.println("+------------------------------------------+");
        System.out.printf("| Transaction ID : %-23s |\n", transactionId);
        System.out.printf("| Slot Number    : #%-22d |\n", slotNumber);
        System.out.printf("| Vehicle Type   : %-23s |\n", allowedVehicleType);
        System.out.printf("| Plate Number   : %-23s |\n", plateNumber);
        System.out.printf("| Intended Stay  : %-23s |\n", hoursParked + " hour(s)");
        System.out.printf("| Timestamp      : %-23s |\n", timestamp);
        System.out.printf("| Flat Rate Fee  : Php %-19.2f |\n", amount);
        System.out.println("+------------------------------------------+");
    }
}