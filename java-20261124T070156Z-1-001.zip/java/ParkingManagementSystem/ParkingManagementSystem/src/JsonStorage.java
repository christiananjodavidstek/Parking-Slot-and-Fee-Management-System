import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class JsonStorage {
    private static final String SLOTS_FILE = "parking_data.json";
    private static final String REVENUE_FILE = "revenue_data.json";

    public static void saveSlots(ParkingSlot[] slots) {
        StringBuilder json = new StringBuilder("[\n");
        for (int i = 0; i < slots.length; i++) {
            ParkingSlot s = slots[i];
            json.append("  {\n")
                    .append("    \"slotNumber\": ").append(s.getSlotNumber()).append(",\n")
                    .append("    \"allowedVehicleType\": \"").append(s.getAllowedVehicleType()).append("\",\n")
                    .append("    \"status\": \"").append(s.getStatus()).append("\",\n")
                    .append("    \"plateNumber\": \"").append(s.getPlateNumber()).append("\",\n")
                    .append("    \"hoursParked\": ").append(s.getHoursParked()).append(",\n")
                    .append("    \"entryTime\": \"").append(s.getEntryTime()).append("\",\n")
                    .append("    \"transactionId\": \"").append(s.getTransactionId()).append("\"\n")
                    .append("  }");
            if (i < slots.length - 1) json.append(",");
            json.append("\n");
        }
        json.append("]");

        try (FileWriter writer = new FileWriter(SLOTS_FILE)) {
            writer.write(json.toString());
        } catch (IOException e) {
            System.out.println("Error saving parking slots: " + e.getMessage());
        }
    }

    public static ParkingSlot[] loadSlots() {
        File file = new File(SLOTS_FILE);
        if (!file.exists()) return null;

        try {
            String content = new String(Files.readAllBytes(Paths.get(SLOTS_FILE))).trim();
            if (content.startsWith("[") && content.endsWith("]")) {
                content = content.substring(1, content.length() - 1).trim();
            }
            if (content.isEmpty()) return null;

            String[] objects = content.split("\\},\\s*\\{");
            List<ParkingSlot> slotList = new ArrayList<>();

            for (String obj : objects) {
                obj = obj.replace("{", "").replace("}", "").trim();
                String[] fields = obj.split(",\n");

                int slotNumber = 0;
                VehicleType type = VehicleType.CAR;
                SlotStatus status = SlotStatus.AVAILABLE;
                String plate = "NONE";
                int hours = 0;
                String entryTime = "N/A";
                String txnId = "N/A";

                for (String field : fields) {
                    String[] kv = field.split(":", 2);
                    String key = kv[0].trim().replace("\"", "");
                    String val = kv[1].trim().replace("\"", "");

                    switch (key) {
                        case "slotNumber": slotNumber = Integer.parseInt(val); break;
                        case "allowedVehicleType": type = VehicleType.valueOf(val); break;
                        case "status": status = SlotStatus.valueOf(val); break;
                        case "plateNumber": plate = val; break;
                        case "hoursParked": hours = Integer.parseInt(val); break;
                        case "entryTime": entryTime = val; break;
                        case "transactionId": txnId = val; break;
                    }
                }

                if (type == VehicleType.MOTORCYCLE) {
                    slotList.add(new MotorcycleSlot(slotNumber, status, plate, hours, entryTime, txnId));
                } else {
                    slotList.add(new CarSlot(slotNumber, status, plate, hours, entryTime, txnId));
                }
            }
            return slotList.toArray(new ParkingSlot[0]);
        } catch (Exception e) {
            System.out.println("Could not read existing JSON, initializing fresh slots.");
            return null;
        }
    }

    public static void saveRevenue(double totalEarnings, int totalVehiclesServed, int txnCounter) {
        String json = "{\n" +
                "  \"totalEarnings\": " + totalEarnings + ",\n" +
                "  \"totalVehiclesServed\": " + totalVehiclesServed + ",\n" +
                "  \"txnCounter\": " + txnCounter + "\n" +
                "}";
        try (FileWriter writer = new FileWriter(REVENUE_FILE)) {
            writer.write(json);
        } catch (IOException e) {
            System.out.println("Error saving revenue data: " + e.getMessage());
        }
    }

    public static double[] loadRevenue() {
        // Returns [totalEarnings, totalVehiclesServed, txnCounter]
        File file = new File(REVENUE_FILE);
        if (!file.exists()) return new double[]{0.0, 0.0, 1001.0};

        try {
            String content = new String(Files.readAllBytes(Paths.get(REVENUE_FILE)))
                    .replace("{", "").replace("}", "").trim();
            String[] fields = content.split(",");
            double earnings = 0.0;
            double served = 0.0;
            double counter = 1001.0;

            for (String field : fields) {
                String[] kv = field.split(":", 2);
                String key = kv[0].trim().replace("\"", "");
                double val = Double.parseDouble(kv[1].trim());
                if (key.equals("totalEarnings")) earnings = val;
                if (key.equals("totalVehiclesServed")) served = val;
                if (key.equals("txnCounter")) counter = val;
            }
            return new double[]{earnings, served, counter};
        } catch (Exception e) {
            return new double[]{0.0, 0.0, 1001.0};
        }
    }
}