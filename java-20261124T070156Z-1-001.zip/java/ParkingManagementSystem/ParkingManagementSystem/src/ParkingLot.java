public class ParkingLot {
    private ParkingSlot[] slots;
    private double totalEarnings;
    private int totalVehiclesServed;
    private int txnCounter;

    public ParkingLot() {
        this.slots = JsonStorage.loadSlots();
        if (this.slots == null) {
            this.slots = new ParkingSlot[30];
            for (int i = 0; i < 15; i++) {
                slots[i] = new MotorcycleSlot(101 + i);
            }
            for (int i = 0; i < 15; i++) {
                slots[15 + i] = new CarSlot(201 + i);
            }
            JsonStorage.saveSlots(this.slots);
        }

        double[] rev = JsonStorage.loadRevenue();
        this.totalEarnings = rev[0];
        this.totalVehiclesServed = (int) rev[1];
        this.txnCounter = (int) rev[2];
    }

    public void displaySummaryHeader() {
        int motoOpen = 0;
        int carOpen = 0;
        for (ParkingSlot s : slots) {
            if (s.getStatus() == SlotStatus.AVAILABLE) {
                if (s.getAllowedVehicleType() == VehicleType.MOTORCYCLE) motoOpen++;
                else carOpen++;
            }
        }
        System.out.println("Available Slots: " + (motoOpen + carOpen) + "/30 " +
                "(Motorcycles: " + motoOpen + "/15 | Cars: " + carOpen + "/15)");
    }

    public void displayVisualGrid() {
        System.out.println("\n--- MOTORCYCLE ZONE (Flat Rate: Php 15.00) ---");
        for (int i = 0; i < 15; i++) {
            String tag = (slots[i].getStatus() == SlotStatus.AVAILABLE)
                    ? "OPEN"
                    : slots[i].getPlateNumber();
            System.out.printf("[%d: %-8s] ", slots[i].getSlotNumber(), tag);
            if ((i + 1) % 5 == 0) System.out.println();
        }

        System.out.println("\n--- CAR ZONE (Flat Rate: Php 25.00) ---");
        for (int i = 15; i < 30; i++) {
            String tag = (slots[i].getStatus() == SlotStatus.AVAILABLE)
                    ? "OPEN"
                    : slots[i].getPlateNumber();
            System.out.printf("[%d: %-8s] ", slots[i].getSlotNumber(), tag);
            if ((i - 15 + 1) % 5 == 0) System.out.println();
        }
    }

    public void parkVehicle(VehicleType type, String plateNumber, int hours) {
        String cleanPlate = plateNumber.toUpperCase().trim();
        if (cleanPlate.isEmpty()) {
            System.out.println("Plate number cannot be empty.");
            return;
        }
        if (hours <= 0) {
            System.out.println("Duration must be at least 1 hour.");
            return;
        }

        // Prevent duplicate active plate numbers
        for (ParkingSlot s : slots) {
            if (s.getStatus() == SlotStatus.OCCUPIED && s.getPlateNumber().equalsIgnoreCase(cleanPlate)) {
                System.out.println("Vehicle [" + cleanPlate + "] is already parked in Slot #" + s.getSlotNumber() + "!");
                return;
            }
        }

        for (ParkingSlot s : slots) {
            if (s.getAllowedVehicleType() == type && s.getStatus() == SlotStatus.AVAILABLE) {
                String txnId = "TXN-" + txnCounter++;
                s.parkVehicle(cleanPlate, hours, txnId);
                saveAll();
                return;
            }
        }
        System.out.println("Sorry, no available slots for " + type + ".");
    }

    public void searchByPlate(String plateNumber) {
        String cleanPlate = plateNumber.toUpperCase().trim();
        for (ParkingSlot s : slots) {
            if (s.getStatus() == SlotStatus.OCCUPIED && s.getPlateNumber().equalsIgnoreCase(cleanPlate)) {
                System.out.println("\n[VEHICLE FOUND]");
                System.out.println("Plate Number : " + s.getPlateNumber());
                System.out.println("Location     : Slot #" + s.getSlotNumber() + " (" + s.getAllowedVehicleType() + ")");
                System.out.println("Entry Time   : " + s.getEntryTime());
                System.out.println("Intended Stay: " + s.getHoursParked() + " hour(s)");
                System.out.println("Fee Due      : Php " + String.format("%.2f", s.calculateFee()));
                return;
            }
        }
        System.out.println("No parked vehicle found with plate number: " + cleanPlate);
    }

    public void releaseBySlot(int slotNumber) {
        for (ParkingSlot s : slots) {
            if (s.getSlotNumber() == slotNumber) {
                if (s.getStatus() == SlotStatus.OCCUPIED) {
                    double fee = s.releaseSlot();
                    totalEarnings += fee;
                    totalVehiclesServed++;
                    saveAll();
                } else {
                    System.out.println("Slot #" + slotNumber + " is already empty.");
                }
                return;
            }
        }
        System.out.println("Slot #" + slotNumber + " does not exist.");
    }

    public void releaseByPlate(String plateNumber) {
        String cleanPlate = plateNumber.toUpperCase().trim();
        for (ParkingSlot s : slots) {
            if (s.getStatus() == SlotStatus.OCCUPIED && s.getPlateNumber().equalsIgnoreCase(cleanPlate)) {
                double fee = s.releaseSlot();
                totalEarnings += fee;
                totalVehiclesServed++;
                saveAll();
                return;
            }
        }
        System.out.println("No parked vehicle found with plate number: " + cleanPlate);
    }

    public void displayRevenueReport() {
        int currentlyParked = 0;
        for (ParkingSlot s : slots) {
            if (s.getStatus() == SlotStatus.OCCUPIED) currentlyParked++;
        }
        System.out.println("\n=== SHIFT & REVENUE SUMMARY ===");
        System.out.println("Currently Parked Vehicles : " + currentlyParked);
        System.out.println("Total Vehicles Checked Out: " + totalVehiclesServed);
        System.out.println("Total Revenue Collected   : Php " + String.format("%.2f", totalEarnings));
    }

    public void saveAll() {
        JsonStorage.saveSlots(slots);
        JsonStorage.saveRevenue(totalEarnings, totalVehiclesServed, txnCounter);
    }
}