public class ParkingSlot {
    private int slotNumber;
    private VehicleType allowedVehicleType;
    private double hourlyRate;
    private SlotStatus status;
    private int hoursParked;

    // Constructor 1: Default constructor (Constructor Chaining)
    public ParkingSlot() {
        this(0, VehicleType.CAR, 50.00);
    }

    // Constructor 2: Slot number only
    public ParkingSlot(int slotNumber) {
        this(slotNumber, VehicleType.CAR, 50.00);
    }

    // Constructor 3: New slot setup
    public ParkingSlot(int slotNumber, VehicleType allowedVehicleType, double hourlyRate) {
        this(slotNumber, allowedVehicleType, hourlyRate, SlotStatus.AVAILABLE, 0);
    }

    // Constructor 4: Full state restoration (used when loading from JSON)
    public ParkingSlot(int slotNumber, VehicleType allowedVehicleType, double hourlyRate, SlotStatus status, int hoursParked) {
        this.slotNumber = slotNumber;
        this.allowedVehicleType = allowedVehicleType;
        this.hourlyRate = hourlyRate;
        this.status = status;
        this.hoursParked = hoursParked;
    }

    // Getters (Accessors)
    public int getSlotNumber() {
        return slotNumber;
    }

    public VehicleType getAllowedVehicleType() {
        return allowedVehicleType;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public SlotStatus getStatus() {
        return status;
    }

    public int getHoursParked() {
        return hoursParked;
    }

    // Setters (Mutators)
    public void setHourlyRate(double hourlyRate) {
        if (hourlyRate > 0) {
            this.hourlyRate = hourlyRate;
        }
    }

    public void setStatus(SlotStatus status) {
        this.status = status;
    }

    // Method Overloading 1: Default 1 hour
    public void parkVehicle() {
        parkVehicle(1);
    }

    // Method Overloading 2: Specific number of hours
    public void parkVehicle(int hours) {
        if (status == SlotStatus.AVAILABLE) {
            if (hours <= 0) {
                System.out.println("Parking duration must be at least 1 hour.");
                return;
            }
            this.status = SlotStatus.OCCUPIED;
            this.hoursParked = hours;
            double totalFee = calculateFee();
            System.out.println("Vehicle parked in Slot #" + slotNumber + " (" + allowedVehicleType + ").");
            System.out.println("Duration: " + hoursParked + " hour(s)");
            System.out.println("Total Payment Due: Php " + String.format("%.2f", totalFee));
        } else {
            System.out.println("Slot #" + slotNumber + " is currently " + status + ".");
        }
    }

    public void releaseSlot() {
        if (status == SlotStatus.OCCUPIED) {
            System.out.println("Slot #" + slotNumber + " cleared. Final payment collected: Php " + String.format("%.2f", calculateFee()));
            this.status = SlotStatus.AVAILABLE;
            this.hoursParked = 0;
        } else {
            System.out.println("Slot #" + slotNumber + " is not currently occupied.");
        }
    }

    public double calculateFee() {
        return hourlyRate * hoursParked;
    }

    public void displaySlotDetails() {
        String extraInfo = (status == SlotStatus.OCCUPIED) ? " | Hours: " + hoursParked + " (Due: Php " + String.format("%.2f", calculateFee()) + ")" : "";
        System.out.println("Slot #" + slotNumber + " | Type: " + allowedVehicleType +
                " | Rate: Php " + String.format("%.2f", hourlyRate) + "/hr | Status: " + status + extraInfo);
    }
}