import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Try loading existing data from parking_data.json
        ParkingSlot[] slots = JsonStorage.loadSlots();

        if (slots == null) {
            System.out.println("No existing database found. Creating default parking slots...");
            slots = new ParkingSlot[] {
                    new ParkingSlot(101, VehicleType.MOTORCYCLE, 25.00),
                    new ParkingSlot(102, VehicleType.MOTORCYCLE, 25.00),
                    new ParkingSlot(103, VehicleType.MOTORCYCLE, 25.00),
                    new ParkingSlot(201, VehicleType.CAR, 50.00),
                    new ParkingSlot(202, VehicleType.CAR, 50.00),
                    new ParkingSlot(203, VehicleType.CAR, 50.00)
            };
            JsonStorage.saveSlots(slots);
        } else {
            System.out.println("Loaded saved parking data from parking_data.json!");
        }

        int choice;
        do {
            System.out.println("\n=== PARKING SLOT AND FEE MANAGEMENT SYSTEM ===");
            displaySlotSummary(slots);
            System.out.println("\n1. View All Parking Slots");
            System.out.println("2. Park a Vehicle");
            System.out.println("3. Release a Parking Slot (Exit)");
            System.out.println("4. Exit System");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("\n--- Slot Directory ---");
                    for (ParkingSlot slot : slots) {
                        slot.displaySlotDetails();
                    }
                    break;

                case 2:
                    System.out.println("\nSelect Vehicle Type:");
                    System.out.println("1. MOTORCYCLE (Php 25.00/hr)");
                    System.out.println("2. CAR        (Php 50.00/hr)");
                    System.out.print("Enter choice (1-2): ");
                    int typeChoice = scanner.nextInt();

                    VehicleType selectedType;
                    switch (typeChoice) {
                        case 1: selectedType = VehicleType.MOTORCYCLE; break;
                        case 2: selectedType = VehicleType.CAR; break;
                        default:
                            System.out.println("Invalid vehicle type.");
                            continue;
                    }

                    ParkingSlot assignedSlot = null;
                    for (ParkingSlot slot : slots) {
                        if (slot.getAllowedVehicleType() == selectedType && slot.getStatus() == SlotStatus.AVAILABLE) {
                            assignedSlot = slot;
                            break;
                        }
                    }

                    if (assignedSlot == null) {
                        System.out.println("Sorry, no available slots for " + selectedType + ".");
                    } else {
                        System.out.print("How many hours will you park? ");
                        int hours = scanner.nextInt();
                        assignedSlot.parkVehicle(hours);
                        JsonStorage.saveSlots(slots);
                    }
                    break;

                case 3:
                    System.out.print("Enter Slot Number to release (e.g., 201): ");
                    int slotNum = scanner.nextInt();
                    boolean found = false;
                    for (ParkingSlot slot : slots) {
                        if (slot.getSlotNumber() == slotNum) {
                            slot.releaseSlot();
                            JsonStorage.saveSlots(slots);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Slot #" + slotNum + " does not exist.");
                    }
                    break;

                case 4:
                    JsonStorage.saveSlots(slots);
                    System.out.println("Data saved to parking_data.json. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (choice != 4);

        scanner.close();
    }

    public static void displaySlotSummary(ParkingSlot[] slots) {
        int availableCount = 0;
        for (ParkingSlot slot : slots) {
            if (slot.getStatus() == SlotStatus.AVAILABLE) {
                availableCount++;
            }
        }
        System.out.println("Available Slots: " + availableCount + " / " + slots.length);
    }
}