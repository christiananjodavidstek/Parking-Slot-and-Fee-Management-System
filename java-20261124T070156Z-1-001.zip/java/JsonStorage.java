import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class JsonStorage {
    private static final String FILE_NAME = "parking_data.json";

    // Saves current slots to parking_data.json
    public static void saveSlots(ParkingSlot[] slots) {
        StringBuilder json = new StringBuilder();
        json.append("[\n");

        for (int i = 0; i < slots.length; i++) {
            ParkingSlot s = slots[i];
            json.append("  {\n");
            json.append("    \"slotNumber\": ").append(s.getSlotNumber()).append(",\n");
            json.append("    \"allowedVehicleType\": \"").append(s.getAllowedVehicleType()).append("\",\n");
            json.append("    \"hourlyRate\": ").append(s.getHourlyRate()).append(",\n");
            json.append("    \"status\": \"").append(s.getStatus()).append("\",\n");
            json.append("    \"hoursParked\": ").append(s.getHoursParked()).append("\n");
            json.append("  }");

            if (i < slots.length - 1) {
                json.append(",");
            }
            json.append("\n");
        }
        json.append("]");

        try (FileWriter writer = new FileWriter(FILE_NAME)) {
            writer.write(json.toString());
        } catch (IOException e) {
            System.out.println("Error saving data to JSON: " + e.getMessage());
        }
    }

    // Loads saved slots from parking_data.json
    public static ParkingSlot[] loadSlots() {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            return null;
        }

        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_NAME))).trim();
            if (content.startsWith("[") && content.endsWith("]")) {
                content = content.substring(1, content.length() - 1).trim();
            }
            if (content.isEmpty()) {
                return null;
            }

            String[] objects = content.split("\\},\\s*\\{");
            List<ParkingSlot> slotList = new ArrayList<>();

            for (String obj : objects) {
                obj = obj.replace("{", "").replace("}", "").trim();
                String[] fields = obj.split(",");

                int slotNumber = 0;
                VehicleType type = VehicleType.CAR;
                double rate = 0.0;
                SlotStatus status = SlotStatus.AVAILABLE;
                int hours = 0;

                for (String field : fields) {
                    String[] keyValue = field.split(":", 2);
                    String key = keyValue[0].trim().replace("\"", "");
                    String val = keyValue[1].trim().replace("\"", "");

                    switch (key) {
                        case "slotNumber":
                            slotNumber = Integer.parseInt(val);
                            break;
                        case "allowedVehicleType":
                            type = VehicleType.valueOf(val);
                            break;
                        case "hourlyRate":
                            rate = Double.parseDouble(val);
                            break;
                        case "status":
                            status = SlotStatus.valueOf(val);
                            break;
                        case "hoursParked":
                            hours = Integer.parseInt(val);
                            break;
                    }
                }
                slotList.add(new ParkingSlot(slotNumber, type, rate, status, hours));
            }

            return slotList.toArray(new ParkingSlot[0]);
        } catch (Exception e) {
            System.out.println("Error loading JSON database, starting fresh: " + e.getMessage());
            return null;
        }
    }
}